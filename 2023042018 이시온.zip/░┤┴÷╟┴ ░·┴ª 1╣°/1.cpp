#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;

class GameObject {
protected:
    int distance;
    int x, y;
public:
    GameObject(int startX, int startY, int distance);
    virtual ~GameObject() {};
    virtual void move() = 0;
    virtual char getShape() = 0;
    int getX() { return x; }
    int getY() { return y; }
};

GameObject::GameObject(int startX, int startY, int distance) {
    this->x = startX;
    this->y = startY;
    this->distance = distance;
}

class Human : public GameObject {
public:
    Human(int x, int y, int z);
    void move();
    char getShape() { return 'H'; }
};

Human::Human(int x, int y, int z) : GameObject(x, y, z) {}

void Human::move() {
    string k;
    for (;;) {
        cout << "����(a), �Ʒ�(s), ��(d), ������(f) >> ";
        cin >> k;
        if (k == "a") {
            if (y != 0) {
                y -= distance;
                break;
            }
            else cout << "�̵��Ұ�" << endl;
        }
        else if (k == "s") {
            if (x != 9) {
                x += distance;
                break;
            }
            else cout << "�̵��Ұ�" << endl;
        }
        else if (k == "d") {
            if (x != 0) {
                x -= distance;
                break;
            }
            else cout << "�̵��Ұ�" << endl;
        }
        else if (k == "f") {
            if (y != 19) {
                y += distance;
                break;
            }
            else cout << "�̵��Ұ�" << endl;
        }
        else
            cout << "�Է� ����" << endl;
    }
}

class Monster : public GameObject {
public:
    Monster(int x, int y, int z) : GameObject(x, y, z) {}
    void move();
    char getShape() { return 'M'; }
};

void Monster::move() {
    for (;;) {
        int n = rand() % 4;
        if (n == 0) {
            if (y > 1) {
                y -= distance;
                break;
            }
        }
        else if (n == 1) {
            if (x < 8) {
                x += distance;
                break;
            }
        }
        else if (n == 2) {
            if (x > 1) {
                x -= distance;
                break;
            }
        }
        else {
            if (y < 18) {
                y += distance;
                break;
            }
        }
    }
}

class Food : public GameObject {
public:
    Food(int x, int y, int dis) : GameObject(x, y, dis) {}
    void move();
    char getShape() { return '@'; }
};

void Food::move() {
    for (;;) {
        int n = rand() % 4;
        if (n == 0) {
            if (y != 0) {
                y -= distance;
                break;
            }
        }
        else if (n == 1) {
            if (x != 9) {
                x += distance;
                break;
            }
        }
        else if (n == 2) {
            if (x != 0) {
                x -= distance;
                break;
            }
        }
        else {
            if (y != 19) {
                y += distance;
                break;
            }
        }
    }
}

class Game {
    string board[10][20];
    Human h;
    Monster m;
    Food f;
public:
    Game();
    void game();
    void clr1();
    void clr2();
    void setXY();
    void show();
};

Game::Game() : h(0, 0, 1), m(7, 7, 2), f(8, 10, 1) {
    srand((unsigned)time(0));
    cout << "** Human�� Food �Ա� ������ �����մϴ�. **" << endl << endl;
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 20; ++j)
            board[i][j] = "-";
    }
}

void Game::clr1() {
    board[h.getX()][h.getY()] = "-";
    board[m.getX()][m.getY()] = "-";
}

void Game::clr2() {
    board[f.getX()][f.getY()] = "-";
}

void Game::setXY() {
    board[h.getX()][h.getY()] = h.getShape();
    board[m.getX()][m.getY()] = m.getShape();
    board[f.getX()][f.getY()] = f.getShape();
}

void Game::show() {
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 20; ++j)
            cout << board[i][j];
        cout << endl;
    }
}

void Game::game() {
    int count = 0, gamecount = 0;
    for (;;) {
        setXY();
        show();
        clr1();
        h.move();
        m.move();
        int n = rand();
        cout << endl;
        if (n % 2 == 0 && count < 2 && gamecount <= 3) {
            clr2();
            f.move();
            ++count;
        }
        if (gamecount > 3 && count < 2) {
            clr2();
            f.move();
            ++count;
        }
        if (h.getX() == f.getX() && h.getY() == f.getY()) {
            setXY();
            board[f.getX()][f.getY()] = "H";
            show();
            cout << "�¸�!!" << endl;
            break;
        }
        else if (h.getX() == m.getX() && h.getY() == m.getY()) {
            setXY();
            board[h.getX()][h.getY()] = "M";
            show();
            cout << "����!!" << endl;
            break;
        }
        else if (f.getX() == m.getX() && f.getY() == m.getY()) {
            setXY();
            board[f.getX()][f.getY()] = "M";
            show();
            cout << "����!!" << endl;
            break;
        }
        ++gamecount;
        if ((gamecount % 5) == 0) {
            count = 0;
            gamecount = 0;
        }
    }
}

int main() {
    Game g;
    g.game();
}
