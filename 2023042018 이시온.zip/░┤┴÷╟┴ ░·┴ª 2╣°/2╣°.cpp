#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include <thread>  
#include <chrono>  
using namespace std;
using namespace std::chrono;

class GameObject {
protected:
    int distance;
    int x, y;
public:
    GameObject(int startX, int startY, int distance);
    virtual ~GameObject() {}
    virtual void move(int key = 0) = 0;
    virtual char getShape() = 0;
    virtual string getColor() = 0;

    int getX() { return x; }
    int getY() { return y; }
    bool collide(GameObject* p) {
        return this->x == p->getX() && this->y == p->getY();
    }
};

class Human : public GameObject {
public:
    Human(int startX, int startY, int distance);
    void move(int key = 0) override {
        switch (key) {
        case 75:
        case 'a':
            if (y - distance < 0) y = 20 + y - distance;
            else y -= distance;
            break;
        case 77:
        case 'f':
            if (y + distance > 19) y = y + distance - 20;
            else y += distance;
            break;
        case 72:
        case 'd':
            if (x - distance < 0) x = 10 + x - distance;
            else x -= distance;
            break;
        case 80:
        case 's':
            if (x + distance > 9) x = x + distance - 10;
            else x += distance;
            break;
        }
    }
    char getShape() override {
        return 'H';
    }
    string getColor() override {
        return "\033[34m";
    }
};

class Monster : public GameObject {
public:
    Monster(int startX, int startY, int distance) : GameObject(startX, startY, distance) {
        srand((unsigned)time(0));
    }
    void move(int key = 0) override {
        int direction = rand() % 4;
        switch (direction) {
        case 0:
            if (x - distance < 0) x = 10 + x - distance;
            else x -= distance;
            break;
        case 1:
            if (x + distance > 9) x = x + distance - 10;
            else x += distance;
            break;
        case 2:
            if (y - distance < 0) y = 20 + y - distance;
            else y -= distance;
            break;
        case 3:
            if (y + distance > 19) y = y + distance - 20;
            else y += distance;
            break;
        }
    }
    char getShape() override {
        return 'M';
    }
    string getColor() override {
        return "\033[31m";
    }
};

class Food : public GameObject {
public:
    Food(int x, int y, int z);
    void move(int key = 0) override {
        int direction = rand() % 4;
        switch (direction) {
        case 0:
            if (y - distance < 0) y = 20 + y - distance;
            else y -= distance;
            break;
        case 1:
            if (x + distance > 9) x = x + distance - 10;
            else x += distance;
            break;
        case 2:
            if (x - distance < 0) x = 10 + x - distance;
            else x -= distance;
            break;
        case 3:
            if (y + distance > 19) y = y + distance - 20;
            else y += distance;
            break;
        }
    }
    char getShape() override {
        return '@';
    }
    string getColor() override {
        return "\033[32m";
    }
};
class Game{
public:
    void game() {
        bool exit = true;
        Human* h = new Human(0, 0, 1);
        Monster* m = new Monster(5, 5, 2);
        Food* f = new Food(8, 9, 1);

        cout << "** Human�� Food �Ա� ������ �����մϴ�." << endl << endl;

        bool startTiming = false;
        steady_clock::time_point startTime;
        while (exit) {
            if (_kbhit()) {
                int key = _getch();
                if (!startTiming) {
                    startTime = steady_clock::now();
                    startTiming = true;
                }
                if (key == 75 || key == 77 || key == 72 || key == 80 || key == 'a' || key == 's' || key == 'd' || key == 'f') {
                    h->move(key);
                }
                if (key == 27 || key == '0') {
                    exit = false;
                    break;
                }
            }

            m->move();
            f->move();

            system("cls");

            cout << "       Food Game\n";
            cout << "��";
            for (int i = 0; i < 20; i++) cout << "��";
            cout << "��" << endl;

            for (int i = 0; i < 10; i++) {
                cout << "��";
                for (int j = 0; j < 20; j++) {
                    if (m->getX() == i && m->getY() == j)
                        cout << m->getColor() << m->getShape() << "\033[0m";
                    else if (h->getX() == i && h->getY() == j)
                        cout << h->getColor() << h->getShape() << "\033[0m";
                    else if (f->getX() == i && f->getY() == j)
                        cout << f->getColor() << f->getShape() << "\033[0m";
                    else
                        cout << '-';
                }
                cout << "��" << endl;
            }

            cout << "��";
            for (int i = 0; i < 20; i++) cout << "��";
            cout << "��" << endl;
            cout << "����(a), �Ʒ�(s), ��(d), ������(f)\n����(<-), �Ʒ�(), ��(^), ������(->)\n �����Ϸ���, ESC �Ǵ� 0 Ű�� ��������.\n";
            if (startTiming) {
                auto currentTime = steady_clock::now();
                auto duration = duration_cast<seconds>(currentTime - startTime).count();
                cout << "\033[33m       �ð�: " << duration << "��\033[0m" << endl;
            }

            if (m->collide(h)) {
                cout << "Human is Loser!!" << endl << "�ΰ��� ���Ϳ��� �������ϴ�." << endl << endl;
                exit = false;
                break;
            }

            else if (h->collide(f)) {
                cout << "Human is Winner!!" << endl << "�ΰ��� ������ �Ծ����ϴ�." << endl << endl;
                exit = false;
                break;
            }

            this_thread::sleep_for(chrono::milliseconds(500));
        }

        delete h;
        delete m;
        delete f;
    }
};
GameObject::GameObject(int startX, int startY, int distance) {
    this->x = startX;
    this->y = startY;
    this->distance = distance;
}

Human::Human(int startX, int startY, int distance) : GameObject(startX, startY, distance) 
{ 

}




Food::Food(int startX, int startY, int distance) : GameObject(startX, startY, distance) 
{
    srand((unsigned)time(0));
}



int main() {
    Game* k = new Game;
    k->game();
    delete k;

    return 0;
}